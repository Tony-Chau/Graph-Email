import React, { Component } from 'react'
import './css/footer.css';

export default class Footer extends Component {
    render() {
        return (
            <span>Developed by <a href="https://github.com/Tony-Chau" target="_blank" rel="noreferrer">Tony Chau</a></span>
        )
    }
}
