import React, { Component } from 'react';

export class Record extends Component {
  render() {
    return (
      <div> textInComponent </div>
    );
  }
}
