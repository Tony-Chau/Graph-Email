import React, { Component } from 'react';
import { Route, Switch, Router } from 'react-router';
import { Layout } from './components/Layout';
import { Home } from './components/Home';
import { Mail } from './components/Mail';

import './custom.css'

export default class App extends Component {
  static displayName = App.name;

  render () {
    return (
      <Layout>
        <Route exact path="/" component={Home}/>
        <Route path="/mail" component={Mail}/>
      </Layout>
    );
  }
}
